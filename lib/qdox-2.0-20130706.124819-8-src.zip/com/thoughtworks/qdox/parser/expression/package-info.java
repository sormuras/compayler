/**
 * Provides classes which make it possible to resolve expression values
 */
package com.thoughtworks.qdox.parser.expression;