/**
 * Provides interfaces and exceptions for both Lexers and Parsers
 */
package com.thoughtworks.qdox.parser;