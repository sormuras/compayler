/**
 * Provides the default implementation of classes to write Java model elements in any style. 
 */
package com.thoughtworks.qdox.writer.impl;